Permite crear una estructura de base de datos con el que se puede generar un menú de usuario para el framework SARA, de esta forma se dan permisos al usuario por página
